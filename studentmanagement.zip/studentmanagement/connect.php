<?php
$server="localhost";
$username="root";
$password="";
$db="school_project";

$con=mysqli_connect($server,$username,$password,$db);

?>